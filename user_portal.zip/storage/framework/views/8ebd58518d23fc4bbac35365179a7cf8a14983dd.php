<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>User Portal</h2>
  <p><a class="btn btn-primary" href="<?php echo e(URL::to('/createuser')); ?>">Add User</a></p>            
  <?php if(session()->has('userid')): ?>
  <p><a class="btn btn-primary" href="<?php echo e(URL::to('/logout')); ?>">Logout</a></p>
  <?php endif; ?>
            
  <table class="table table-striped">

<thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Salary</th>
        <th>Action</th>
    </tr>
</thead>
 <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user['id']); ?></td>
    
        <td><?php echo e($user['name']); ?></td>
    
        <td><?php echo e($user['email']); ?></td>
        <td>$ <?php echo e($user['salary'] ? $user['salary'] : 0); ?></td>
    
        <td>
            <a onclick="setuserid(this.id);" id="<?php echo e($user['id']); ?>" data-toggle="modal" data-target="#myModal" href="javascript:void(0)">Add Salary | </a> 
            <a href="<?php echo e(URL::to('/viewuser')); ?>/<?php echo e($user['id']); ?>">Edit | </a> 
            <a href="<?php echo e(URL::to('/deleteuser')); ?>/<?php echo e($user['id']); ?>">Delete</a> 
            
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>

</table>

</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">User Salary</h4>
      </div>
      <form method="post" action="<?php echo e(URL::to('/updateSalary')); ?>">
        <?php echo e(csrf_field()); ?>

      <div class="modal-body">
        
            <div class="form-group">
                <label for="salary">Salary:</label>
                <input minlength="1" min="1" type="number" name="salary" class="form-control" id="salary" value="">
                <input type="hidden" name="userid" id="uid" value="">
            </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
    </div>
  </div>
</div>
<script type="text/javascript">
    function setuserid(id){
        $('#uid').val(id);
    }
    
</script>
</body>
</html>
