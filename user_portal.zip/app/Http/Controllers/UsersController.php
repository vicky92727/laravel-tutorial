<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Usersalary;
class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();


        $users = User::leftjoin('usersalaries', 'usersalaries.user_id', '=', 'users.id')
                ->select('usersalaries.salary','users.id', 'users.name','users.email')
                ->get();


        return view('users',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('userform');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = new User;
        $user['name'] = request('name');
        $user['email'] = request('email');
        $user['password'] = request('password');

        $this->validate($request, [
        'name' => 'required|min:3|max:50',
        'email' => 'required|unique:users|email',
        'password' => 'required|confirmed|min:6',
        ]);
        $user->save();
        $request->session()->flash('flash_message', 'User successfully added!');
        return redirect('/users');
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = new User;
        $user = $user->find($id);
        //dd($user);
        return view('showuser',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   

        $this->validate($request, [
        'name' => 'required|min:3|max:50',
        'email' => 'unique:users,email,'.$id
        ]);
        $user = User::findOrFail($id);
        $user->update($request->all());
        $request->session()->flash('flash_message', 'User successfully updated!');
        return redirect('/users');
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateSalary(Request $request)
    {  



        $id = request('userid');
        $salary = new Usersalary;
        $salaryid = Usersalary::select('id')->where('user_id', $id)->first();
        if ($salaryid) {
            $userSalary = Usersalary::findOrFail($salaryid);
            $userSalary->update($request->all());

        } else {

            
            $salary['user_id'] = request('userid');
            $salary['salary'] = request('salary');
            $salary->save();
        }
        $request->session()->flash('flash_message', 'User successfully updated!');
        return redirect('/users');
        
    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        $request->session()->flash('flash_message', 'User successfully deleted!');
        return redirect('/users');
    }
}
